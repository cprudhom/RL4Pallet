# RL4Pallet

### References

- [creating-environments](https://github.com/openai/gym/blob/master/docs/creating-environments.md)

Command line: `pip install -e gym_pallet`